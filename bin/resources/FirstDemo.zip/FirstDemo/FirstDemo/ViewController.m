//
//  ViewController.m
//  FirstDemo
//
//  Created by Vishnu Karthik on 08/07/13.
//  Copyright (c) 2013 Vishnu Karthik. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize myText;
@synthesize myLabel;

-(IBAction)changeLabel:(id)sender{
    NSString * message = [[NSString alloc] initWithFormat:@"Hello %@", [ myText text] ];
    [myLabel setText:message];
    [myText resignFirstResponder];
}


-(void)viewDidAppear:(BOOL)animated{
//    UIAlertView * uiAlertView = [[UIAlertView alloc]initWithTitle:@"A title" message:@"Boo yea!" delegate:nil cancelButtonTitle:@"Okies" otherButtonTitles:@"hmm", nil];
//    [uiAlertView show];

}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}

@end
