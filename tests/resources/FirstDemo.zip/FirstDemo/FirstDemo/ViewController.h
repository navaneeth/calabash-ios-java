//
//  ViewController.h
//  FirstDemo
//
//  Created by Vishnu Karthik on 08/07/13.
//  Copyright (c) 2013 Vishnu Karthik. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *myText;
@property (weak, nonatomic) IBOutlet UILabel *myLabel;

-(IBAction)changeLabel:(id)sender;

- (IBAction)dismissKeyboard:(id)sender;
@end
